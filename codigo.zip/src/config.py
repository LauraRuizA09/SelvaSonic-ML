"""
src/config.py
=============

Configuración centralizada de SelvaSonic.

Este módulo es la **fuente única de verdad** para todos los hiperparámetros
del pipeline de datos del proyecto. Cualquier módulo (audio_io, transforms,
dataset, etc.) que necesite conocer un parámetro debe importarlo desde aquí,
NUNCA hardcodearlo localmente.

Ventajas de centralizar:
- Un solo lugar para revisar/modificar configuración del proyecto.
- Reproducibilidad: el reporte final puede simplemente referenciar este archivo.
- Coherencia: imposible que dos módulos usen valores distintos de SAMPLE_RATE.
- Experimentación rápida: cambiar un hiperparámetro = cambiar un solo número.

Convención: TODAS las constantes en MAYÚSCULAS_CON_GUIÓN_BAJO (PEP 8).

Autoras(es)
-----------
Laura Ruiz Arango & Jose Aldair Molina Méndez
Universidad Nacional de Colombia - Sede Medellín
Aprendizaje Automático (Prof. Alcides Montoya) - 2026
"""

from __future__ import annotations

from pathlib import Path


# =============================================================================
# 0. RUTAS BASE
# =============================================================================
# Definidas antes de las constantes que las usan (CLASS_WEIGHTS_PATH en s. 7).
# Se derivan del __file__ del módulo para ser robustas tanto en local
# (Windows) como en Colab (/content/SelvaSonic-ML/).

DATA_DIR: Path = Path(__file__).resolve().parent.parent / "data"
"""Ruta absoluta al directorio data/ del proyecto (independiente de OS).

Ejemplo local:   C:/Users/…/SelvaSonic ML/data
Ejemplo Colab:  /content/SelvaSonic-ML/data
"""


# =============================================================================
# 1. AUDIO I/O
# =============================================================================
# Constantes que controlan la carga de audio desde disco.
# Usadas por: src/audio_io.py

SAMPLE_RATE: int = 22_050
"""Frecuencia de muestreo unificada del proyecto, en Hz.

Justificación (teorema de Nyquist):
    Las vocalizaciones de aves amazónicas se concentran en el rango
    500 Hz - 10 kHz. Con sr = 22,050 Hz, la frecuencia máxima
    representable es sr/2 = 11,025 Hz, suficiente para capturar
    toda la información biológicamente relevante.

Trade-off:
    Usar 22,050 Hz en lugar de 44,100 Hz (calidad CD) reduce a la mitad
    el tamaño de los arrays y acelera el entrenamiento, sin perder
    información útil para clasificación de aves.
"""

MONO: bool = True
"""Todos los audios se convierten a mono (un solo canal).

Justificación:
    La identificación de especies por vocalización no depende de
    información espacial (estéreo). Trabajar en mono reduce el tamaño
    del tensor y simplifica el pipeline.
"""

SUPPORTED_EXTENSIONS: tuple[str, ...] = (".mp3", ".wav", ".flac", ".ogg")
"""Formatos de audio que el pipeline puede leer.

Xeno-canto entrega MP3, ESC-50 entrega WAV. Los otros (FLAC, OGG)
se incluyen por si en el futuro se añaden datasets adicionales.
"""


# =============================================================================
# 2. EXTRACCIÓN DE MEL-SPECTROGRAMAS
# =============================================================================
# Constantes que controlan el cálculo del Mel-spectrograma a partir
# del waveform. Usadas por: src/transforms.py

N_FFT: int = 2048
"""Tamaño de la ventana FFT (número de muestras por frame).

Justificación:
    - Resolución frecuencial: Δf = SAMPLE_RATE / N_FFT = 22050/2048 ≈ 10.8 Hz/bin
    - Suficiente para distinguir tonos de aves (cuyas variaciones son >> 10 Hz)
    - Estándar de facto en bioacústica con sr=22050.

Trade-off (principio de incertidumbre tiempo-frecuencia):
    - N_FFT más grande → mejor resolución frecuencial, peor temporal
    - N_FFT más pequeño → mejor resolución temporal, peor frecuencial
    - 2048 es el equilibrio establecido en el campo.
"""

HOP_LENGTH: int = 512
"""Paso (en muestras) entre ventanas FFT consecutivas.

Justificación:
    - Resolución temporal: Δt = HOP_LENGTH / SAMPLE_RATE ≈ 23 ms por frame
    - Captura trinos rápidos de aves (sílabas de ~50-100 ms tienen 2-4 frames)
    - Ratio N_FFT/HOP_LENGTH = 4 → overlap del 75% entre ventanas (estándar).
"""

N_MELS: int = 128
"""Número de bandas en el banco de filtros Mel.

Justificación:
    - 128 es el estándar moderno en clasificación de audio
      (YAMNet, AST, PANNs, BirdNET).
    - Da suficiente detalle para que el CNN aprenda patrones espectrales
      sin ser excesivo (más bandas = más cómputo, ganancia marginal).
    - Coincide con la arquitectura declarada en el README de SelvaSonic.
"""

FMIN: float = 50.0
"""Frecuencia mínima del banco de filtros Mel, en Hz.

Justificación:
    - Por debajo de 50 Hz hay principalmente ruido (cable, viento, motores).
    - Las aves no emiten contenido relevante en frecuencias tan bajas.
    - Filtrar este rango reduce ruido sin perder información de canto.
"""

FMAX: float = 11_025.0
"""Frecuencia máxima del banco de filtros Mel, en Hz.

Justificación:
    - Es el límite de Nyquist: SAMPLE_RATE / 2 = 11,025 Hz.
    - Es físicamente imposible representar frecuencias mayores con
      el sample rate del proyecto.
"""


# =============================================================================
# 3. SEGMENTACIÓN DE CLIPS
# =============================================================================
# Constantes que controlan el corte de audios largos en clips uniformes.
# Usadas por: src/segmentation.py, src/dataset.py

CLIP_DURATION_S: float = 5.0
"""Duración estándar de cada clip de entrenamiento, en segundos.

Justificación:
    - 5 segundos es el estándar en bioacústica computacional
      (BirdCLEF, BirdNET, AST-bird).
    - Suficiente para capturar al menos un canto completo de la mayoría
      de aves amazónicas.
    - Coincide con la duración nativa de ESC-50 (también 5s) → no requiere
      padding cuando se entrena con clases negativas.
"""

CLIP_NUM_SAMPLES: int = int(CLIP_DURATION_S * SAMPLE_RATE)
"""Número de muestras de un clip estándar (constante derivada).

Calculado automáticamente: CLIP_DURATION_S * SAMPLE_RATE = 5.0 * 22050 = 110250.
Usado para padding/truncate de clips que no midan exactamente 5s.
NO modificar manualmente — depende de CLIP_DURATION_S y SAMPLE_RATE.
"""

CLIP_OVERLAP_RATIO: float = 0.5
"""Solapamiento entre clips consecutivos, fracción en [0.0, 1.0).

Valores típicos:
    - 0.0 → clips adyacentes (sin solape)
    - 0.5 → 50% de solape (cada clip avanza 2.5s) — RECOMENDADO
    - 0.75 → 75% de solape (más datos, redundancia alta)

Justificación:
    Con solape 50%, un audio de 30s genera 11 clips en lugar de 6.
    Es data augmentation honesto: ventanas distintas del mismo evento
    acústico ayudan al modelo a aprender invarianza temporal.

IMPORTANTE: Solo aplicar solape en TRAIN, nunca en VAL/TEST.
    Si dos clips de validación se solapan al 50%, comparten el 50% de
    sus muestras → métricas infladas (data leakage entre clips).
"""

SHORT_AUDIO_STRATEGY: str = "wrap"
"""Estrategia para audios MÁS CORTOS que CLIP_DURATION_S.

Opciones:
    "wrap"  → repetición circular (loop) — preserva propiedades estadísticas
    "zero"  → padding con ceros — introduce silencio artificial (no recomendado)
    "drop"  → descartar el audio — pérdida de datos

Justificación de "wrap" como default:
    El padding con ceros mete silencio que la CNN puede aprender como
    "feature de borde" (sesgo). El padding circular conserva la firma
    espectral del canto, manteniendo el espectrograma coherente.
"""

LEFTOVER_STRATEGY: str = "wrap"
"""Estrategia para el SOBRANTE al final de un audio largo.

Ejemplo: audio de 12s con clips de 5s y solape 0 → 2 clips + 2s sobrantes.
¿Qué hacer con esos 2s?

Opciones:
    "wrap"  → completar con repetición desde el inicio del sobrante
    "drop"  → descartar el sobrante (más limpio, pierde poco)
    "zero"  → padding con ceros (no recomendado)

Solo se procesa el sobrante si dura ≥ MIN_LEFTOVER_SEC (ver abajo).
"""

MIN_LEFTOVER_SEC: float = 2.0
"""Mínima duración (en segundos) del sobrante para procesarlo.

Justificación:
    Un sobrante de 0.3s rellenado con repetición produciría un clip
    casi totalmente sintético — ruido para el modelo. A partir de 2s
    de audio "real" hay suficiente firma espectral para que el clip
    aporte información, incluso después del padding.
"""


# =============================================================================
# 4. DATA AUGMENTATION
# =============================================================================
# Constantes que controlan el aumento de datos sintético del training set.
# Usadas por: src/augmentation.py, src/dataset.py
#
# IMPORTANTE: Solo aplicar augmentation en TRAIN. Nunca en VAL/TEST.

TIME_STRETCH_RANGE: tuple[float, float] = (0.8, 1.25)
"""Rango de factores para time stretch (cambio de velocidad sin alterar tono).

Interpretación:
    - rate < 1.0 -> audio MÁS LARGO (ave cantando "lento")
    - rate = 1.0 -> sin cambio
    - rate > 1.0 -> audio MÁS CORTO (ave cantando "rápido")

Justificación de [0.8, 1.25]:
    - Aves reales cantan a velocidades variables según contexto
      (excitación, fatiga, distancia al receptor).
    - Más allá de ±25% el algoritmo (phase vocoder) introduce artefactos
      audibles que el modelo aprendería como ruido.
    - Rango simétrico en escala logarítmica: 1/1.25 = 0.8.
"""

PITCH_SHIFT_RANGE: tuple[int, int] = (-2, 2)
"""Rango de semitones para pitch shift (cambio de tono sin alterar duración).

Unidades: semitones. 12 semitones = 1 octava. f' = f * 2^(n/12).

Justificación de [-2, +2]:
    - ±2 semitones -> frecuencias multiplicadas por [0.89, 1.12]
    - Cubre variación natural entre individuos de la misma especie
      (machos vs hembras, juveniles vs adultos).
    - Más allá ±2 cambia la firma espectral demasiado y el ave deja
      de ser reconocible para un experto humano.
"""

SNR_DB_RANGE: tuple[float, float] = (10.0, 30.0)
"""Rango de SNR (Signal-to-Noise Ratio) en decibelios para add_noise.

SNR_dB = 10 * log10(P_señal / P_ruido)

Interpretación práctica:
    - SNR = 30 dB -> ruido apenas audible (ambiente silencioso)
    - SNR = 20 dB -> ruido moderado (selva con viento ligero)
    - SNR = 10 dB -> ruido fuerte (lluvia, mucho ambiente)
    - SNR < 10 dB -> ave imperceptible, basura para el modelo

Justificación:
    Simula condiciones reales de campo (ej. los audios de los
    compañeros del Amazonas) donde siempre hay ruido ambiental.
    Entrenar con SNR variable hace al modelo robusto a contextos.
"""

AUG_PROB_TIME_STRETCH: float = 0.5
"""Probabilidad de aplicar time stretch a cada clip de TRAIN.

Justificación:
    50% es estándar en bioacústica. Si fuera 100% perderíamos la
    representación del audio "natural" sin modificar. Si fuera muy bajo,
    la augmentation no tendría efecto suficiente.
"""

AUG_PROB_PITCH_SHIFT: float = 0.5
"""Probabilidad de aplicar pitch shift a cada clip de TRAIN."""

AUG_PROB_ADD_NOISE: float = 0.7
"""Probabilidad de aplicar add noise a cada clip de TRAIN.

Justificación:
    Más alta que las otras (70% vs 50%) porque el ruido es la condición
    MÁS REALISTA en producción. Las aves casi nunca se graban en silencio
    absoluto, así que conviene exponer al modelo a ruido frecuentemente.
"""


# =============================================================================
# 5. RESERVADO PARA FUTURO (Semanas 3-6)
# =============================================================================
# Estos hiperparámetros se irán llenando conforme avance el proyecto.
# Se dejan documentados aquí para tener un "mapa" de qué falta configurar.

# --- Modelo (Semana 3) ---
NUM_CLASSES: int = 11
"""Número total de clases del clasificador (10 especies + clase 'no_ave').

Justificación:
    El dataset de SelvaSonic cubre 10 especies amazónicas colombianas más
    una clase negativa (ESC-50 / sonidos no-ave). La clase no_ave recibe
    la etiqueta 0 por convención (primera columna de la matriz de confusión).
"""

CNN_CHANNELS: list[int] = [32, 64, 128, 256]
"""Número de filtros en cada bloque convolucional del feature extractor.

Justificación:
    Progresión geométrica ×2 por bloque (32→64→128→256): estándar desde
    VGGNet (Simonyan & Zisserman, 2014). Cada bloque aprende representaciones
    más abstractas en un espacio más rico. El tope en 256 balancea capacidad
    representacional con el tamaño del dataset (~330 audios).
"""

DROPOUT: float = 0.3
"""Tasa de dropout en la cabeza clasificadora (después del primer FC).

Justificación:
    0.3 es conservador: suficiente para regularizar sin degradar demasiado
    el flujo de gradientes. Valores > 0.5 son arriesgados con datasets
    pequeños donde ya hay pocas muestras por clase.
"""

ATTENTION_NUM_HEADS: int = 4
"""Número de cabezas de atención en el módulo Multi-Head Self-Attention.

Justificación:
    - El feature map del CNN tiene d=256 canales. Con 4 cabezas, cada una
      opera en 256/4 = 64 dimensiones, el valor canónico del Transformer
      original (Vaswani et al. 2017) que balancea expresividad y estabilidad.
    - 8 cabezas darían 32 dims/cabeza, demasiado angosto para capturar
      patrones espectrales ricos.
    - Con un dataset pequeño (~330 audios), más cabezas aumentarían el
      riesgo de overfitting sin ganancia clara.
"""

ATTENTION_DROPOUT: float = 0.1
"""Dropout dentro del módulo de atención (sobre los pesos de atención).

Justificación:
    Valor estándar en Transformers. Más bajo que el dropout del clasificador
    (0.3) porque el attention ya es un cuello de información que regulariza
    de por sí.
"""

# --- Entrenamiento (Semana 4) ---
# BATCH_SIZE: int = 32
# LEARNING_RATE: float = 1e-3
# NUM_EPOCHS: int = 50
# WEIGHT_DECAY: float = 1e-4

# --- Inferencia (Semana 5-6) ---
# CONFIDENCE_THRESHOLD: float = 0.6  # Por debajo → "No identificado"


# =============================================================================
# 6. LOGGING
# =============================================================================
# Constantes que controlan el logging con TensorBoard.
# Usadas por: src/logger.py

TENSORBOARD_ENABLED: bool = True
"""Si activar TensorBoard durante entrenamiento.

Útil desactivar (False) en tests, debugging local rápido, o ejecuciones
donde no se quiere generar logs (ej. smoke tests automáticos).
"""

TENSORBOARD_LOG_DIR_NAME: str = "tensorboard"
"""Nombre del subdirectorio donde guardar logs de TensorBoard dentro de
cada run. Estructura final: runs/<run_name>/tensorboard/events.out.*"""

LOG_CONFUSION_MATRIX_EVERY_N_EPOCHS: int = 5
"""Cada cuántas épocas registrar matriz de confusión en TensorBoard.

Justificación:
    Generar la matriz cada época es costoso (requiere correr inferencia
    sobre validation set + generar figura matplotlib). Cada 5 épocas da
    suficiente granularidad para ver evolución sin overhead.
"""


# =============================================================================
# 7. MEJORAS DE LOSS (Fase 3: class weights + label smoothing)
# =============================================================================
# Ver docs/decisiones_metodologicas.md sección 2 para justificación completa.
# Estas constantes controlan la construcción de la loss en src/loss.py.

USE_CLASS_WEIGHTS: bool = True
"""Si True, aplica weighting inversamente proporcional a la frecuencia de cada
clase en CrossEntropyLoss. Mitiga el desbalance severo del dataset (Chordeiles
tiene peso ~5.4x, Trogon tiene ~0.47x). Requiere CLASS_WEIGHTS_PATH generado
por `python scripts/calcular_class_weights.py`.

Justificación:
    Sin class weights, la loss penaliza igual un error en no_ave (1,120 clips
    train) que en Chordeiles_pusillus (240 clips). El modelo aprende a ignorar
    clases minoritarias. Con weighting inverso, los errores en clases raras
    valen proporcionalmente más, forzando al modelo a aprenderlas.
"""

LABEL_SMOOTHING_ALPHA: float = 0.1
"""Parámetro alpha de label smoothing para CrossEntropyLoss.

0.0 = sin smoothing (etiquetas one-hot puras).
0.1 = estándar de la literatura (Müller et al., NeurIPS 2019, "When Does
      Label Smoothing Help?"). Suaviza las etiquetas: la clase correcta
      recibe probabilidad 1 - alpha + alpha/K en lugar de 1.0.

Justificación:
    El modelo attention v1 mostró overconfidence bias (notebook 11): predicciones
    con probabilidad > 0.95 incluso en audios ambiguos. Label smoothing previene
    que el modelo se vuelva demasiado confiado al penalizar predicciones cercanas
    a 1.0, mejorando la calibración de probabilidades.

Efectos prácticos:
    - Reduce la brecha train_loss / val_loss (regularización implícita).
    - Mejora el Expected Calibration Error (ECE).
    - No cambia el argmax de las predicciones → accuracy no se ve afectado.
"""

CLASS_WEIGHTS_PATH: Path = DATA_DIR / "class_weights.pt"
"""Ruta al tensor de class weights precomputados.

Se genera corriendo: python scripts/calcular_class_weights.py
Contiene: weights tensor [11], label_map, class_counts, class_frequencies.
Excluido de git (*.pt en .gitignore) — regenerar si cambia el dataset.
"""
